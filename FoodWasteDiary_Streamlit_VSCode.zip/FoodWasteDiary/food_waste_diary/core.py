from datetime import date
from uuid import uuid4

CATEGORIES = ["Fruit", "Vegetable", "Grain", "Dairy", "Meat", "Prepared", "Other"]
REASONS = ["Spoiled", "Expired", "Leftovers", "Over-prepared", "Damaged", "Other"]

def validate_record(food_name, category, quantity, reason, entry_date):
    name = str(food_name).strip()
    category = str(category).strip().title()
    reason = str(reason).strip() or "Other"
    if not name: raise ValueError("Food name cannot be blank.")
    if category not in CATEGORIES: raise ValueError("Choose a valid category.")
    try: quantity = float(quantity)
    except (ValueError, TypeError): raise ValueError("Quantity must be a number.")
    if not 0 < quantity <= 1000: raise ValueError("Quantity must be greater than 0 and at most 1000 kg.")
    try: date.fromisoformat(str(entry_date))
    except ValueError: raise ValueError("Date must be YYYY-MM-DD.")
    return {"id": str(uuid4())[:8], "food_name": name, "category": category, "quantity_kg": round(quantity, 3), "reason": reason, "entry_date": str(entry_date)}

def search_records(records, keyword="", category="All"):
    keyword = keyword.strip().lower()
    return [r for r in records if (not keyword or keyword in r["food_name"].lower() or keyword in r["reason"].lower()) and (category == "All" or r["category"] == category)]

def summarize(records):
    total = sum(float(r["quantity_kg"]) for r in records)
    by_category = {}
    by_day = {}
    for r in records:
        by_category[r["category"]] = by_category.get(r["category"], 0) + float(r["quantity_kg"])
        by_day[r["entry_date"]] = by_day.get(r["entry_date"], 0) + float(r["quantity_kg"])
    return {"entries": len(records), "total_kg": round(total, 3), "average_kg": round(total / len(records), 3) if records else 0, "by_category": dict(sorted(by_category.items(), key=lambda x: -x[1])), "by_day": dict(sorted(by_day.items()))}
