import csv, json
from pathlib import Path
from datetime import date

FIELDS = ["id", "food_name", "category", "quantity_kg", "reason", "entry_date"]

class Storage:
    def __init__(self, data_dir="data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "records.json"
        self.csv_path = self.data_dir / "records.csv"

    def load(self):
        if not self.json_path.exists():
            return []
        try:
            records = json.loads(self.json_path.read_text(encoding="utf-8"))
            return records if isinstance(records, list) else []
        except (json.JSONDecodeError, OSError):
            print("Warning: records.json was unreadable. Starting with an empty record list.")
            return []

    def save(self, records):
        self.json_path.write_text(json.dumps(records, indent=2), encoding="utf-8")
        with self.csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(records)

    def import_csv(self, path):
        imported, errors = [], []
        try:
            with open(path, newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for line, row in enumerate(reader, start=2):
                    try:
                        name = str(row.get("food_name", "")).strip()
                        category = str(row.get("category", "")).strip().title()
                        quantity = float(row.get("quantity_kg", ""))
                        reason = str(row.get("reason", "Other")).strip() or "Other"
                        entry_date = str(row.get("entry_date", date.today().isoformat())).strip()
                        date.fromisoformat(entry_date)
                        if not name or category not in {"Fruit", "Vegetable", "Grain", "Dairy", "Meat", "Prepared", "Other"} or quantity <= 0:
                            raise ValueError("invalid name/category/quantity")
                        imported.append({"id": "", "food_name": name, "category": category, "quantity_kg": round(quantity, 3), "reason": reason, "entry_date": entry_date})
                    except (ValueError, TypeError):
                        errors.append(f"Row {line}: invalid or incomplete record")
        except OSError as e:
            errors.append(f"Could not read file: {e}")
        return imported, errors
