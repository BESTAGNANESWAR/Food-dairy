import csv
from pathlib import Path
from .storage import FIELDS
from .core import summarize

def export_csv(records, path):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS); writer.writeheader(); writer.writerows(records)
    return path

def export_summary(records, path, fmt="md"):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    s = summarize(records)
    lines = ["# Food Waste Diary Summary", "", f"- Records: {s['entries']}", f"- Total waste: {s['total_kg']:.3f} kg", f"- Average per record: {s['average_kg']:.3f} kg", "", "## Waste by category"]
    lines += [f"- {k}: {v:.3f} kg" for k, v in s["by_category"].items()] or ["- No data yet"]
    lines += ["", "## Daily waste trend"]
    lines += [f"- {k}: {v:.3f} kg" for k, v in s["by_day"].items()] or ["- No data yet"]
    text = "\n".join(lines)
    if fmt == "txt": text = text.replace("# ", "").replace("## ", "\n")
    path.write_text(text, encoding="utf-8")
    return path

def make_chart(records, path):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    s = summarize(records)
    if not s["by_category"]: return None
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    cats, vals = list(s["by_category"].keys()), list(s["by_category"].values())
    ax.bar(cats, vals); ax.set_title("Food Waste by Category"); ax.set_ylabel("Waste (kg)"); ax.tick_params(axis="x", rotation=25); fig.tight_layout(); fig.savefig(path, dpi=160); plt.close(fig)
    return path
