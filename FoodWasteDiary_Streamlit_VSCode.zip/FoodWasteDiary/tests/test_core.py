import unittest
from food_waste_diary.core import validate_record, summarize, search_records


class CoreTests(unittest.TestCase):
    def test_valid_record(self):
        r = validate_record("Apple", "Fruit", "0.25", "Spoiled", "2026-11-21")
        self.assertEqual(r["food_name"], "Apple")
        self.assertAlmostEqual(r["quantity_kg"], 0.25)
    def test_reject_zero_quantity(self):
        with self.assertRaises(ValueError): validate_record("Rice", "Grain", 0, "Other", "2026-11-21")
    def test_reject_bad_date(self):
        with self.assertRaises(ValueError): validate_record("Rice", "Grain", 1, "Other", "bad-date")
    def test_summary(self):
        data = [validate_record("Apple", "Fruit", 0.5, "Spoiled", "2026-11-20"), validate_record("Rice", "Grain", 1, "Leftovers", "2026-11-20")]
        s = summarize(data)
        self.assertEqual(s["entries"], 2); self.assertAlmostEqual(s["total_kg"], 1.5)
    def test_search_category(self):
        data = [validate_record("Apple", "Fruit", 0.5, "Spoiled", "2026-11-20")]
        self.assertEqual(len(search_records(data, "app", "Fruit")), 1)

if __name__ == "__main__": unittest.main()
