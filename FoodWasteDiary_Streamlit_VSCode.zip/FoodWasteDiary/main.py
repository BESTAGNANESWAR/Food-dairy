from datetime import date
from pathlib import Path
from food_waste_diary.core import validate_record, search_records, summarize, CATEGORIES
from food_waste_diary.storage import Storage
from food_waste_diary.reports import export_csv, export_summary, make_chart


ROOT = Path(__file__).resolve().parent
storage = Storage(ROOT / "data")
records = storage.load()

def header():
    print("\n" + "=" * 54 + "\n       FOOD WASTE DIARY | LOCAL ANALYTICS\n" + "=" * 54)

def input_nonempty(prompt):
    while True:
        value = input(prompt).strip()
        if value: return value
        print("Please enter a value.")

def add_record():
    print("\n-- Add a record --")
    name = input_nonempty("Food name: ")
    print("Categories: " + ", ".join(CATEGORIES))
    category = input_nonempty("Category: ").title()
    quantity = input_nonempty("Discarded quantity (kg): ")
    reason = input("Reason (Spoiled/Expired/Leftovers/Over-prepared/Damaged/Other): ").strip() or "Other"
    entry_date = input(f"Date [default {date.today()}]: ").strip() or date.today().isoformat()
    try:
        record = validate_record(name, category, quantity, reason, entry_date)
        records.append(record); storage.save(records)
        print("Saved record successfully.")
    except ValueError as e: print(f"Validation: {e}")

def list_records(items=None):
    items = records if items is None else items
    if not items: print("No records found."); return
    print(f"\n{'DATE':<12} {'FOOD':<20} {'CATEGORY':<12} {'KG':>8} {'REASON'}")
    print("-" * 74)
    for r in items:
        print(f"{r['entry_date']:<12} {r['food_name'][:19]:<20} {r['category']:<12} {float(r['quantity_kg']):>8.3f} {r['reason']}")
    print(f"Showing {len(items)} record(s).")

def analytics():
    s = summarize(records)
    print("\n-- Summary --")
    print(f"Records: {s['entries']} | Total discarded: {s['total_kg']:.3f} kg | Average: {s['average_kg']:.3f} kg")
    if s["by_category"]:
        print("\nCategory breakdown:")
        for cat, kg in s["by_category"].items(): print(f"  {cat:<12} {kg:>8.3f} kg")
        largest = next(iter(s["by_category"].items()))
        print(f"\nHighest waste category: {largest[0]} ({largest[1]:.3f} kg)")
        print("\nDaily trend:")
        for day, kg in s["by_day"].items(): print(f"  {day}: {kg:.3f} kg")
    else: print("Add entries to see analytics.")

def search():
    key = input("Search food/reason keyword (blank = all): ")
    cat = input("Category (or All): ").strip().title() or "All"
    if cat not in ["All"] + CATEGORIES: print("Unknown category; showing all categories."); cat = "All"
    list_records(search_records(records, key, cat))

def import_csv():
    path = input_nonempty("CSV file path: ")
    imported, errors = storage.import_csv(path)
    for r in imported: r["id"] = __import__("uuid").uuid4().hex[:8]
    records.extend(imported); storage.save(records)
    print(f"Imported {len(imported)} valid rows.")
    if errors:
        print("Rows skipped:"); [print(" - " + e) for e in errors]

def exports():
    out = ROOT / "exports"
    print("\n1. Export records CSV\n2. Summary Markdown\n3. Summary TXT\n4. Chart PNG")
    choice = input("Choose: ").strip()
    try:
        if choice == "1": print("Saved:", export_csv(records, out / "food_waste_export.csv"))
        elif choice == "2": print("Saved:", export_summary(records, out / "summary.md", "md"))
        elif choice == "3": print("Saved:", export_summary(records, out / "summary.txt", "txt"))
        elif choice == "4":
            path = make_chart(records, out / "category_chart.png")
            print("Chart saved:" if path else "Chart unavailable (install matplotlib or add records).", path or "")
        else: print("Invalid option.")
    except OSError as e: print("Export failed:", e)

def main():
    while True:
        header()
        print("1. Add food waste record\n2. View records\n3. Search / filter records\n4. Analytics summary\n5. Export reports / chart\n6. Import CSV dataset\n7. Exit")
        choice = input("\nSelect an option (1-7): ").strip()
        if choice == "1": add_record()
        elif choice == "2": list_records()
        elif choice == "3": search()
        elif choice == "4": analytics()
        elif choice == "5": exports()
        elif choice == "6": import_csv()
        elif choice == "7": print("Data saved locally. Goodbye!"); break
        else: print("Choose a number from 1 to 7.")
        input("\nPress Enter to return to the menu...")

if __name__ == "__main__": main()
