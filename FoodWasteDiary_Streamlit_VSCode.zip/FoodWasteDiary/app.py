from datetime import date
from pathlib import Path
import pandas as pd
import streamlit as st

from food_waste_diary.core import validate_record, search_records, summarize, CATEGORIES, REASONS
from food_waste_diary.storage import Storage
from food_waste_diary.reports import export_csv, export_summary, make_chart

ROOT = Path(__file__).resolve().parent
storage = Storage(ROOT / "data")

st.set_page_config(page_title="Food Waste Diary", page_icon="🥗", layout="wide")

def load_records():
    return storage.load()

def refresh_records(records):
    storage.save(records)

records = load_records()

st.title("🥗 Food Waste Diary")
st.caption("Record food waste, review patterns, and export simple reports. Your data stays on this computer.")
st.divider()

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Choose a section", ["Dashboard", "Add Record", "All Records", "Search & Filter", "Reports & Export"])
    st.divider()
    st.caption("Local storage")
    st.code("data/records.json\ndata/records.csv", language="text")

summary = summarize(records)

if page == "Dashboard":
    st.subheader("Waste overview")
    c1, c2, c3 = st.columns(3)
    c1.metric("Total records", summary["entries"])
    c2.metric("Total food waste", f'{summary["total_kg"]:.3f} kg')
    c3.metric("Average per record", f'{summary["average_kg"]:.3f} kg')
    st.divider()
    left, right = st.columns(2)
    with left:
        st.markdown("#### Waste by category")
        if summary["by_category"]:
            chart_data = pd.DataFrame(
                [{"Category": k, "Waste (kg)": v} for k, v in summary["by_category"].items()]
            ).set_index("Category")
            st.bar_chart(chart_data)
            highest = next(iter(summary["by_category"].items()))
            st.info(f"Highest waste category: **{highest[0]}** ({highest[1]:.3f} kg)")
        else:
            st.info("No records yet. Add your first food waste entry.")
    with right:
        st.markdown("#### Daily waste trend")
        if summary["by_day"]:
            daily = pd.DataFrame(
                [{"Date": pd.to_datetime(k), "Waste (kg)": v} for k, v in summary["by_day"].items()]
            ).set_index("Date")
            st.line_chart(daily)
        else:
            st.info("Daily trend will appear after you add records.")
    if records:
        st.markdown("#### Recent entries")
        recent = sorted(records, key=lambda x: x["entry_date"], reverse=True)[:5]
        st.dataframe(pd.DataFrame(recent)[["entry_date", "food_name", "category", "quantity_kg", "reason"]],
                     use_container_width=True, hide_index=True)

elif page == "Add Record":
    st.subheader("Add food waste record")
    with st.form("add_record_form", clear_on_submit=True):
        col1, col2 = st.columns(2)
        with col1:
            food_name = st.text_input("Food name", placeholder="e.g. Rice, Apple, Bread")
            category = st.selectbox("Category", CATEGORIES)
            quantity = st.number_input("Discarded quantity (kg)", min_value=0.001, max_value=1000.0,
                                       value=0.250, step=0.050, format="%.3f")
        with col2:
            reason = st.selectbox("Reason", REASONS)
            entry_date = st.date_input("Date", value=date.today())
        submitted = st.form_submit_button("Save record", type="primary")
        if submitted:
            try:
                record = validate_record(food_name, category, quantity, reason, entry_date.isoformat())
                records.append(record)
                refresh_records(records)
                st.success("Record saved successfully.")
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))

elif page == "All Records":
    st.subheader("All food waste records")
    if records:
        df = pd.DataFrame(records)
        df = df[["entry_date", "food_name", "category", "quantity_kg", "reason", "id"]]
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.caption(f"{len(records)} record(s)")
        if st.button("Delete all records", type="secondary"):
            refresh_records([])
            st.warning("All records deleted.")
            st.rerun()
    else:
        st.info("No records found. Use Add Record to create one.")

elif page == "Search & Filter":
    st.subheader("Search and filter records")
    col1, col2 = st.columns([2, 1])
    with col1:
        keyword = st.text_input("Search food name or reason", placeholder="Type a keyword")
    with col2:
        category_filter = st.selectbox("Category", ["All"] + CATEGORIES)
    filtered = search_records(records, keyword, category_filter)
    if filtered:
        st.dataframe(pd.DataFrame(filtered)[["entry_date", "food_name", "category", "quantity_kg", "reason"]],
                     use_container_width=True, hide_index=True)
        st.caption(f"Found {len(filtered)} matching record(s)")
    else:
        st.info("No matching records.")

elif page == "Reports & Export":
    st.subheader("Reports and export")
    st.write("Download your records or a summary report.")
    if records:
        csv_path = export_csv(records, ROOT / "exports" / "food_waste_export.csv")
        md_path = export_summary(records, ROOT / "exports" / "summary.md", "md")
        txt_path = export_summary(records, ROOT / "exports" / "summary.txt", "txt")
        col1, col2, col3 = st.columns(3)
        col1.download_button("⬇️ Download records CSV", csv_path.read_bytes(),
                             file_name="food_waste_export.csv", mime="text/csv", use_container_width=True)
        col2.download_button("⬇️ Download summary MD", md_path.read_text(encoding="utf-8"),
                             file_name="food_waste_summary.md", mime="text/markdown", use_container_width=True)
        col3.download_button("⬇️ Download summary TXT", txt_path.read_text(encoding="utf-8"),
                             file_name="food_waste_summary.txt", mime="text/plain", use_container_width=True)
        st.divider()
        st.markdown("#### Category chart")
        chart_path = make_chart(records, ROOT / "exports" / "category_chart.png")
        if chart_path and chart_path.exists():
            st.image(str(chart_path), caption="Food waste by category", use_container_width=True)
            st.download_button("⬇️ Download chart PNG", chart_path.read_bytes(),
                               file_name="food_waste_category_chart.png", mime="image/png")
        else:
            st.info("Chart is unavailable. Install matplotlib or add records.")
    else:
        st.info("Add records first. Export options will appear here.")
    st.divider()
    st.markdown("#### Import records from CSV")
    st.caption("Required columns: food_name, category, quantity_kg, reason, entry_date")
    uploaded = st.file_uploader("Choose a CSV file", type=["csv"])
    if uploaded is not None and st.button("Import CSV"):
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tmp:
            tmp.write(uploaded.getvalue())
            temp_name = tmp.name
        imported, errors = storage.import_csv(temp_name)
        Path(temp_name).unlink(missing_ok=True)
        if imported:
            import uuid
            for row in imported:
                row["id"] = uuid.uuid4().hex[:8]
            records.extend(imported)
            refresh_records(records)
            st.success(f"Imported {len(imported)} valid row(s).")
        if errors:
            st.warning("Some rows were skipped:")
            for error in errors:
                st.write(f"- {error}")
        st.rerun()

st.divider()
st.caption("Food Waste Diary • Python + Streamlit • Data is stored locally; it is not uploaded.")
