# Food Waste Diary — Streamlit Interface

This version adds a browser-based interface to the existing Python project. It retains the original validation, JSON/CSV storage, search, analytics, CSV import, reports, and unit tests.

## Run in VS Code (Windows)

1. Extract `FoodWasteDiary_Streamlit_VSCode.zip`.
2. Open the extracted `FoodWasteDiary` folder in VS Code.
3. Select **Terminal → New Terminal**.
4. Check Python: `python --version`
5. Create a virtual environment:

   ```powershell
   python -m venv .venv
   ```

6. Activate it:

   ```powershell
   .venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then activate again.

7. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

8. Run the interface:

   ```powershell
   streamlit run app.py
   ```

Streamlit opens the app in your browser, usually at `http://localhost:8501`. Keep the terminal open while demonstrating. Press **Ctrl+C** in the terminal to stop it.

## Features to demonstrate

- **Dashboard:** total records, total waste, average waste, category chart, daily trend.
- **Add Record:** enter food name, category, quantity, reason, and date.
- **All Records:** view saved entries.
- **Search & Filter:** search food/reason and filter by category.
- **Reports & Export:** download CSV, Markdown, TXT, and chart files; import a CSV dataset.

## Files and data

- `app.py` — Streamlit interface
- `main.py` — original command-line interface
- `food_waste_diary/` — shared validation, storage, analytics, and report logic
- `data/records.json` and `data/records.csv` — local saved data
- `exports/` — generated reports
- `tests/` — unit tests

Data stays on your computer and is not uploaded.

## Other commands

Original command-line version: `python main.py`

Run tests: `python -m unittest discover -s tests -v`

CSV import requires headers: `food_name,category,quantity_kg,reason,entry_date`. Allowed categories: Fruit, Vegetable, Grain, Dairy, Meat, Prepared, Other. Dates use `YYYY-MM-DD`; quantity is in kilograms and must be greater than zero.
